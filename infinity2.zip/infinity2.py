a = 3
while a < float("inf"):
    print a
    a = a**10
    